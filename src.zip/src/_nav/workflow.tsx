// src/_nav/workflow.tsx
// Navigation du module "Gestion des demandes" (workflow CAP)
// Affichée selon le rôle de l'utilisateur connecté.
// Tous les liens pointent vers /demandes — le WorkflowRouter gère les tabs en interne.

import CIcon from '@coreui/icons-react'
import {
  cilInbox,
  cilTask,
  cilCheckAlt,
  cilDescription,
  cilFolder,
  cilPen,
  cilList,
} from '@coreui/icons'
import { CNavItem, CNavTitle } from '@coreui/react'
import type { UserRole } from '@/constants'

const getWorkflowNavigation = (role: UserRole | null) => {
  // ── Secrétaire / Admin : accès complet ─────────────────────────────────────
  if (role === 'secretaire' || role === 'admin') {
    return [
      {
        component: CNavTitle,
        name: 'Gestion des demandes',
      },
      {
        component: CNavItem,
        name: 'Tableau de bord',
        to: '/demandes',
        icon: <CIcon icon={cilInbox} customClassName="nav-icon" />,
      },
      {
        component: CNavTitle,
        name: 'Accès rapide',
      },
      {
        component: CNavItem,
        name: 'Nouvelles demandes',
        to: '/demandes?tab=pending',
        icon: <CIcon icon={cilInbox} customClassName="nav-icon" />,
      },
      {
        component: CNavItem,
        name: 'En cours',
        to: '/demandes?tab=secretaire_review',
        icon: <CIcon icon={cilTask} customClassName="nav-icon" />,
      },
      {
        component: CNavItem,
        name: 'À corriger',
        to: '/demandes?tab=secretaire_correction',
        icon: <CIcon icon={cilPen} customClassName="nav-icon" />,
      },
      {
        component: CNavItem,
        name: 'Prêts à retirer',
        to: '/demandes?tab=ready',
        icon: <CIcon icon={cilCheckAlt} customClassName="nav-icon" />,
      },
      {
        component: CNavItem,
        name: 'Tous / Archivés',
        to: '/demandes?tab=delivered',
        icon: <CIcon icon={cilList} customClassName="nav-icon" />,
      },
    ]
  }

  // ── Chef Division ──────────────────────────────────────────────────────────
  if (role === 'chef-division') {
    return [
      {
        component: CNavTitle,
        name: 'Dossiers à valider',
      },
      {
        component: CNavItem,
        name: 'Dossiers en attente',
        to: '/demandes',
        icon: <CIcon icon={cilDescription} customClassName="nav-icon" />,
      },
    ]
  }

  // ── Comptable ──────────────────────────────────────────────────────────────
  if (role === 'comptable') {
    return [
      {
        component: CNavTitle,
        name: 'Vérification financière',
      },
      {
        component: CNavItem,
        name: 'Dossiers à vérifier',
        to: '/demandes',
        icon: <CIcon icon={cilTask} customClassName="nav-icon" />,
      },
    ]
  }

  // ── Chef CAP ───────────────────────────────────────────────────────────────
  if (role === 'chef-cap') {
    return [
      {
        component: CNavTitle,
        name: 'Signature / Paraphe',
      },
      {
        component: CNavItem,
        name: 'Documents à signer',
        to: '/demandes',
        icon: <CIcon icon={cilPen} customClassName="nav-icon" />,
      },
    ]
  }

  // ── Directeur Adjoint / Directeur ──────────────────────────────────────────
  if ((role as string) === 'directeur-adjoint' || (role as string) === 'directeur') {
    return [
      {
        component: CNavTitle,
        name: 'Signature',
      },
      {
        component: CNavItem,
        name: 'Documents à signer',
        to: '/demandes',
        icon: <CIcon icon={cilCheckAlt} customClassName="nav-icon" />,
      },
    ]
  }

  return []
}

export default getWorkflowNavigation
