// src/views/pages/attestation/workflow/ChefCapDashboard.tsx

import { useState, useCallback, useEffect } from 'react'
import {
  CCard, CCardBody, CCardHeader, CRow, CCol, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CButton, CSpinner, CFormInput, CInputGroup, CInputGroupText,
  CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter,
  CAlert, CBadge, CFormCheck,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilSearch, cilInbox, cilExternalLink, cilPen, cilX } from '@coreui/icons'
import documentRequestService from '@/services/document-request.service'
import type { DocumentRequest, SignatureType } from '@/types/document-request.types'
import { TYPE_LABELS } from '@/types/document-request.types'
import { WorkflowTimeline } from '@/components/document-request/WorkflowBadge'
import MotifModal from '@/components/document-request/MotifModal'
import DossierFiles from '@/components/document-request/DossierFiles'

const DetailModal = ({
  demande, visible, onClose, onAction,
}: {
  demande: DocumentRequest | null
  visible: boolean
  onClose: () => void
  onAction: (action: string, signatureType?: SignatureType, motif?: string) => Promise<void>
}) => {
  const [sigType, setSigType] = useState<SignatureType>('signature')
  const [loading, setLoading] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  const [rejectModal, setRejectModal] = useState(false)

  if (!demande) return null

  const do_ = async (action: string, st?: SignatureType, motif?: string) => {
    setLoading(true)
    try { await onAction(action, st, motif); onClose() }
    finally { setLoading(false); setConfirmed(false) }
  }

  return (
    <>
      <CModal visible={visible} onClose={onClose} size="lg" alignment="center" scrollable>
        <CModalHeader>
          <CModalTitle>Signature / Paraphe — <code className="text-muted fw-normal">#{demande.reference}</code></CModalTitle>
        </CModalHeader>

        <CModalBody>
          <WorkflowTimeline currentStatus={demande.status} />
          <CRow className="mt-3 g-2">
            <CCol md={6}>
              <div className="border rounded p-3 bg-light h-100">
                <p className="fw-semibold mb-2 text-uppercase small text-muted">Étudiant</p>
                <p className="fw-bold mb-1">{demande.last_name} {demande.first_names}</p>
                <p className="small text-muted mb-0">Matricule : {demande.matricule || '—'}</p>
              </div>
            </CCol>
            <CCol md={6}>
              <div className="border rounded p-3 bg-light h-100">
                <p className="fw-semibold mb-2 text-uppercase small text-muted">Document</p>
                <p className="fw-bold mb-1">{TYPE_LABELS[demande.type] ?? demande.type}</p>
                <p className="small text-muted mb-0">
                  Soumis le : {demande.submitted_at ? new Date(demande.submitted_at).toLocaleDateString('fr-FR') : '—'}
                </p>
              </div>
            </CCol>
          </CRow>
          <div className="mt-3">
            <p className="fw-semibold small text-muted text-uppercase mb-2">Pièces du dossier</p>
            <DossierFiles files={demande.files} />
          </div>

          {/* Choix type signature */}
          <div className="mt-3 p-3 border rounded" style={{ background: '#fffbeb' }}>
            <p className="fw-semibold small mb-2">Type d'approbation</p>
            <div className="d-flex gap-3">
              {([
                { v: 'paraphe',   label: 'Paraphe',           desc: '→ Directeur Adjoint puis Directeur', color: 'primary' },
                { v: 'signature', label: 'Signature complète', desc: '→ Directeur directement',           color: 'success' },
              ] as const).map(opt => (
                <div
                  key={opt.v}
                  className={`flex-fill border rounded p-3 text-center`}
                  style={{
                    cursor: 'pointer',
                    borderColor: sigType === opt.v ? `var(--cui-${opt.color})` : '#e5e7eb',
                    background: sigType === opt.v ? `var(--cui-${opt.color}-bg, #f0f9ff)` : 'white',
                  }}
                  onClick={() => setSigType(opt.v)}
                >
                  <div className="fw-semibold">{opt.label}</div>
                  <div className="text-muted" style={{ fontSize: '0.75rem' }}>{opt.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <CAlert color="warning" className="mt-3 py-2 small">
            ⚠ Votre décision est définitive. Si vous rejetez, le dossier retourne à la secrétaire.
          </CAlert>
          <div className="d-flex align-items-center gap-2 mt-2">
            <CFormCheck id="confirm-cap" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} />
            <label htmlFor="confirm-cap" className="mb-0 small">
              J'ai vérifié le dossier et confirme ma décision.
            </label>
          </div>
        </CModalBody>

        <CModalFooter className="gap-2 bg-light">
          <CButton color="secondary" variant="ghost" onClick={onClose} disabled={loading}>Fermer</CButton>
          <CButton color="danger" variant="outline" onClick={() => setRejectModal(true)} disabled={loading}>
            <CIcon icon={cilX} className="me-1" /> Rejeter
          </CButton>
          <CButton
            color={sigType === 'paraphe' ? 'primary' : 'success'}
            onClick={() => do_('chef_cap_sign', sigType)}
            disabled={loading || !confirmed}
          >
            <CIcon icon={cilPen} className="me-1" />
            {sigType === 'paraphe' ? 'Parapher & Transmettre' : 'Signer & Transmettre'}
          </CButton>
        </CModalFooter>
      </CModal>

      <MotifModal
        visible={rejectModal}
        title="Rejeter — retour à la secrétaire"
        confirmLabel="Rejeter"
        confirmColor="danger"
        onClose={() => setRejectModal(false)}
        onConfirm={async (motif) => { await do_('chef_cap_reject', undefined, motif); setRejectModal(false) }}
      />
    </>
  )
}

const ChefCapDashboard = () => {
  const [demandes, setDemandes] = useState<DocumentRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<DocumentRequest | null>(null)
  const [detailOpen, setDetailOpen] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try { const res = await documentRequestService.getAll({ search }); setDemandes(res.data || []) }
    catch (e) { console.error(e) }
    finally { setLoading(false) }
  }, [search])

  useEffect(() => { load() }, [load])

  const handleAction = async (action: string, signatureType?: SignatureType, motif?: string) => {
    if (!selected) return
    await documentRequestService.transition(selected.id, { action, signature_type: signatureType, motif })
    await load()
  }

  return (
    <div>
      <CRow className="mb-4">
        <CCol md={4}>
          <div className="border rounded p-3" style={{ borderLeftWidth: 4, borderLeftColor: '#0ea5e9', background: '#f0f9ff' }}>
            <div className="text-muted small">Documents à signer</div>
            <div className="fw-bold" style={{ fontSize: '2rem', color: '#0ea5e9' }}>{demandes.length}</div>
          </div>
        </CCol>
      </CRow>

      <CCard className="shadow-sm">
        <CCardHeader className="d-flex justify-content-between align-items-center bg-white">
          <div>
            <strong>Documents à signer / parapher</strong>
            <div className="text-muted small">Chef CAP</div>
          </div>
          <CInputGroup size="sm" style={{ width: 220 }}>
            <CInputGroupText><CIcon icon={cilSearch} /></CInputGroupText>
            <CFormInput placeholder="Référence, nom…" value={search} onChange={e => setSearch(e.target.value)} />
          </CInputGroup>
        </CCardHeader>

        <CCardBody className="p-0">
          {loading ? (
            <div className="text-center py-5"><CSpinner color="primary" /></div>
          ) : demandes.length === 0 ? (
            <div className="text-center py-5 text-muted">
              <CIcon icon={cilInbox} size="3xl" className="mb-2 d-block mx-auto opacity-25" />
              <div>Aucun document en attente de signature</div>
            </div>
          ) : (
            <CTable hover responsive className="align-middle mb-0">
              <CTableHead style={{ background: '#f8fafc' }}>
                <CTableRow>
                  <CTableHeaderCell>Référence</CTableHeaderCell>
                  <CTableHeaderCell>Étudiant</CTableHeaderCell>
                  <CTableHeaderCell>Type</CTableHeaderCell>
                  <CTableHeaderCell>Date</CTableHeaderCell>
                  <CTableHeaderCell style={{ width: 60 }}></CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {demandes.map(d => (
                  <CTableRow key={d.id} style={{ cursor: 'pointer' }} onClick={() => { setSelected(d); setDetailOpen(true) }}>
                    <CTableDataCell><code className="text-primary" style={{ fontSize: '0.82rem' }}>{d.reference}</code></CTableDataCell>
                    <CTableDataCell>
                      <div className="fw-semibold">{d.last_name} {d.first_names}</div>
                      <small className="text-muted">{d.matricule || '—'}</small>
                    </CTableDataCell>
                    <CTableDataCell><small>{TYPE_LABELS[d.type] ?? d.type}</small></CTableDataCell>
                    <CTableDataCell>
                      <small className="text-muted">
                        {d.submitted_at ? new Date(d.submitted_at).toLocaleDateString('fr-FR') : '—'}
                      </small>
                    </CTableDataCell>
                    <CTableDataCell>
                      <CButton color="primary" size="sm" variant="ghost"><CIcon icon={cilExternalLink} /></CButton>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
          )}
        </CCardBody>
      </CCard>

      <DetailModal
        demande={selected}
        visible={detailOpen}
        onClose={() => { setDetailOpen(false); setSelected(null) }}
        onAction={handleAction}
      />
    </div>
  )
}

export default ChefCapDashboard
