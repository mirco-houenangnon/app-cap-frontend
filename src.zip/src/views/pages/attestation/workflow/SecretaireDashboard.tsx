// src/views/pages/attestation/workflow/SecretaireDashboard.tsx

import { useState, useEffect, useCallback } from 'react'
import {
  CCard, CCardBody, CCardHeader, CRow, CCol, CTable, CTableHead,
  CTableRow, CTableHeaderCell, CTableBody, CTableDataCell,
  CButton, CSpinner, CBadge, CFormSelect, CFormInput,
  CInputGroup, CInputGroupText, CModal, CModalHeader,
  CModalTitle, CModalBody, CModalFooter, CAlert, CTooltip,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilSearch, cilCheckAlt, cilX, cilSend, cilExternalLink,
  cilInbox, cilWarning, cilReload,
} from '@coreui/icons'
import documentRequestService from '@/services/document-request.service'
import type {
  DocumentRequest, ChefDivisionType,
} from '@/types/document-request.types'
import {
  TYPE_LABELS, CHEF_DIVISION_LABELS, RESEND_OPTIONS,
  STATUS_LABELS, STATUS_ORDER,
} from '@/types/document-request.types'
import { WorkflowBadge } from '@/components/document-request/WorkflowBadge'
import { WorkflowTimeline } from '@/components/document-request/WorkflowBadge'
import MotifModal from '@/components/document-request/MotifModal'
import DossierFiles from '@/components/document-request/DossierFiles'

const TABS = [
  { key: 'pending',                 label: 'Nouvelles',        color: 'warning', icon: '📥' },
  { key: 'secretaire_review',       label: 'En cours',         color: 'info',    icon: '📋' },
  { key: 'chef_division_review',    label: 'Chef Division',    color: 'primary', icon: '👤' },
  { key: 'comptable_review',        label: 'Comptabilité',     color: 'primary', icon: '💰' },
  { key: 'chef_cap_review',         label: 'Chef CAP',         color: 'primary', icon: '✍️' },
  { key: 'directeur_adjoint_review',label: 'Dir. Adjoint',    color: 'primary', icon: '📝' },
  { key: 'directeur_review',        label: 'Directeur',        color: 'primary', icon: '🖊️' },
  { key: 'ready',                   label: 'Prêts',            color: 'success', icon: '✅' },
  { key: 'rejected_pending_resend', label: 'Rejets à traiter', color: 'danger',  icon: '⚠️' },
  { key: 'delivered',               label: 'Archivés',         color: 'secondary',icon: '📦' },
  { key: 'rejected',                label: 'Rejetés',          color: 'dark',    icon: '🚫' },
]

// ─── Modal de choix du chef division ─────────────────────────────────────────
const ChefDivisionModal = ({
  visible, onClose, onConfirm, loading,
}: {
  visible: boolean
  onClose: () => void
  onConfirm: (type: ChefDivisionType) => void
  loading: boolean
}) => (
  <CModal visible={visible} onClose={onClose} alignment="center">
    <CModalHeader>
      <CModalTitle>Choisir le Chef Division</CModalTitle>
    </CModalHeader>
    <CModalBody>
      <p className="text-muted small mb-4">
        Sélectionnez le chef de division concerné par ce dossier.
      </p>
      <div className="d-flex gap-3">
        {(['formation_distance', 'formation_continue'] as ChefDivisionType[]).map(type => (
          <CButton
            key={type}
            color="primary"
            variant="outline"
            className="flex-fill py-3"
            onClick={() => onConfirm(type)}
            disabled={loading}
          >
            <div className="fw-bold">{CHEF_DIVISION_LABELS[type]}</div>
          </CButton>
        ))}
      </div>
    </CModalBody>
    <CModalFooter>
      <CButton color="secondary" onClick={onClose} disabled={loading}>Annuler</CButton>
    </CModalFooter>
  </CModal>
)

// ─── Modal de renvoi après rejet ──────────────────────────────────────────────
const ResendModal = ({
  demande, visible, onClose, onConfirm, loading,
}: {
  demande: DocumentRequest | null
  visible: boolean
  onClose: () => void
  onConfirm: (resendTo: string, chefDivType?: ChefDivisionType) => void
  loading: boolean
}) => {
  const [resendTo, setResendTo] = useState('')
  const [chefDivType, setChefDivType] = useState<ChefDivisionType>('formation_distance')

  if (!demande) return null

  // Limiter les options au niveau qui a rejeté
  const rejectedAtIdx = STATUS_ORDER.indexOf(demande.rejected_at_status as any)
  const allowedOptions = RESEND_OPTIONS.filter(opt => {
    const optIdx = STATUS_ORDER.indexOf(opt.status)
    return rejectedAtIdx === -1 || optIdx <= rejectedAtIdx
  })

  return (
    <CModal visible={visible} onClose={onClose} alignment="center">
      <CModalHeader>
        <CModalTitle>Renvoyer le dossier</CModalTitle>
      </CModalHeader>
      <CModalBody>
        <CAlert color="warning" className="py-2 mb-3">
          <strong>Rejeté par :</strong> {demande.rejected_by || '—'}<br />
          <strong>Motif :</strong> {demande.rejected_reason || '—'}
        </CAlert>
        <p className="fw-semibold small mb-2">Renvoyer à quel niveau ?</p>
        <div className="d-flex flex-column gap-2 mb-3">
          {allowedOptions.map(opt => (
            <CButton
              key={opt.value}
              color={resendTo === opt.value ? 'primary' : 'light'}
              className="text-start"
              onClick={() => setResendTo(opt.value)}
            >
              {resendTo === opt.value ? '● ' : '○ '}{opt.label}
            </CButton>
          ))}
        </div>
        {resendTo === 'chef_division' && (
          <div>
            <p className="fw-semibold small mb-2">Quel chef division ?</p>
            <div className="d-flex gap-2">
              {(['formation_distance', 'formation_continue'] as ChefDivisionType[]).map(t => (
                <CButton
                  key={t}
                  size="sm"
                  color={chefDivType === t ? 'primary' : 'light'}
                  onClick={() => setChefDivType(t)}
                >
                  {CHEF_DIVISION_LABELS[t]}
                </CButton>
              ))}
            </div>
          </div>
        )}
      </CModalBody>
      <CModalFooter>
        <CButton color="secondary" onClick={onClose} disabled={loading}>Annuler</CButton>
        <CButton
          color="primary"
          onClick={() => resendTo && onConfirm(resendTo, resendTo === 'chef_division' ? chefDivType : undefined)}
          disabled={!resendTo || loading}
        >
          {loading ? <CSpinner size="sm" /> : 'Renvoyer'}
        </CButton>
      </CModalFooter>
    </CModal>
  )
}

// ─── Modal de détail ──────────────────────────────────────────────────────────
const DetailModal = ({
  demande, visible, onClose, onAction,
}: {
  demande: DocumentRequest | null
  visible: boolean
  onClose: () => void
  onAction: (action: string, extra?: Record<string, any>) => Promise<void>
}) => {
  const [loading, setLoading] = useState(false)
  const [motifModal, setMotifModal] = useState({ open: false, action: '' })
  const [chefDivModal, setChefDivModal] = useState(false)
  const [resendModal, setResendModal] = useState(false)

  if (!demande) return null

  const do_ = async (action: string, extra?: Record<string, any>) => {
    setLoading(true)
    try {
      await onAction(action, extra)
      onClose()
    } finally { setLoading(false) }
  }

  const s = demande.status

  return (
    <>
      <CModal visible={visible} onClose={onClose} size="lg" alignment="center" scrollable>
        <CModalHeader className="border-bottom-0 pb-0">
          <CModalTitle className="d-flex align-items-center gap-2">
            <span>Demande</span>
            <code className="text-muted fw-normal" style={{ fontSize: '0.85rem' }}>#{demande.reference}</code>
            <WorkflowBadge status={demande.status} size="sm" />
          </CModalTitle>
        </CModalHeader>

        <CModalBody>
          <WorkflowTimeline currentStatus={demande.status} isRejected={s === 'rejected' || s === 'rejected_pending_resend'} />

          <CRow className="mt-3 g-2">
            <CCol md={6}>
              <div className="border rounded p-3 h-100 bg-light">
                <p className="fw-semibold mb-2 text-uppercase small text-muted">Étudiant</p>
                <p className="mb-1 fw-bold">{demande.last_name} {demande.first_names}</p>
                <p className="mb-1 small text-muted">Matricule : {demande.matricule || '—'}</p>
                <p className="mb-1 small text-muted">Filière : {demande.department || '—'}</p>
                <p className="mb-0 small text-muted">Année : {demande.academic_year || '—'}</p>
              </div>
            </CCol>
            <CCol md={6}>
              <div className="border rounded p-3 h-100 bg-light">
                <p className="fw-semibold mb-2 text-uppercase small text-muted">Demande</p>
                <p className="mb-1 fw-bold">{TYPE_LABELS[demande.type] ?? demande.type}</p>
                <p className="mb-1 small text-muted">
                  Soumis le : {demande.submitted_at ? new Date(demande.submitted_at).toLocaleDateString('fr-FR') : '—'}
                </p>
                {demande.chef_division_type && (
                  <p className="mb-0 small">
                    <CBadge color="info">{CHEF_DIVISION_LABELS[demande.chef_division_type]}</CBadge>
                  </p>
                )}
              </div>
            </CCol>
          </CRow>

          <div className="mt-3">
            <p className="fw-semibold small text-muted text-uppercase mb-2">Pièces jointes</p>
            <DossierFiles files={demande.files} />
          </div>

          {/* Commentaires reçus */}
          {demande.chef_division_comment && (
            <CAlert color="warning" className="mt-3 py-2 small">
              <strong>Chef Division :</strong> {demande.chef_division_comment}
            </CAlert>
          )}
          {demande.comptable_comment && (
            <CAlert color="info" className="mt-2 py-2 small">
              <strong>Comptable :</strong> {demande.comptable_comment}
            </CAlert>
          )}
          {(s === 'rejected_pending_resend' || s === 'rejected') && demande.rejected_reason && (
            <CAlert color="danger" className="mt-2 py-2 small">
              <strong>Motif de rejet ({demande.rejected_by}) :</strong> {demande.rejected_reason}
            </CAlert>
          )}
        </CModalBody>

        <CModalFooter className="flex-wrap gap-2 bg-light border-top">
          <CButton color="secondary" variant="ghost" onClick={onClose} disabled={loading}>Fermer</CButton>

          {/* Nouvelle demande → prendre en charge */}
          {s === 'pending' && (
            <CButton color="success" onClick={() => do_('secretaire_accept')} disabled={loading}>
              <CIcon icon={cilCheckAlt} className="me-1" /> Prendre en charge
            </CButton>
          )}

          {/* En cours → envoyer au chef division (choix du type) */}
          {s === 'secretaire_review' && (
            <>
              <CButton color="primary" onClick={() => setChefDivModal(true)} disabled={loading}>
                <CIcon icon={cilSend} className="me-1" /> Envoyer au Chef Division
              </CButton>
              <CButton color="danger" variant="outline" onClick={() => setMotifModal({ open: true, action: 'secretaire_reject' })} disabled={loading}>
                <CIcon icon={cilX} className="me-1" /> Rejeter
              </CButton>
            </>
          )}

          {/* Rejeté en attente → renvoyer ou rejeter définitivement */}
          {s === 'rejected_pending_resend' && (
            <>
              <CButton color="primary" onClick={() => setResendModal(true)} disabled={loading}>
                <CIcon icon={cilReload} className="me-1" /> Renvoyer
              </CButton>
              <CButton color="danger" onClick={() => setMotifModal({ open: true, action: 'secretaire_reject_final' })} disabled={loading}>
                <CIcon icon={cilX} className="me-1" /> Rejeter définitivement
              </CButton>
            </>
          )}

          {/* Prêt → marquer retiré */}
          {s === 'ready' && (
            <CButton color="success" onClick={() => do_('secretaire_deliver')} disabled={loading}>
              <CIcon icon={cilCheckAlt} className="me-1" /> Marquer comme retiré
            </CButton>
          )}
        </CModalFooter>
      </CModal>

      {/* Modal choix chef division */}
      <ChefDivisionModal
        visible={chefDivModal}
        onClose={() => setChefDivModal(false)}
        loading={loading}
        onConfirm={(type) => {
          setChefDivModal(false)
          do_('secretaire_send_chef_division', { chef_division_type: type })
        }}
      />

      {/* Modal renvoi après rejet */}
      <ResendModal
        demande={demande}
        visible={resendModal}
        onClose={() => setResendModal(false)}
        loading={loading}
        onConfirm={(resendTo, chefDivType) => {
          setResendModal(false)
          do_('secretaire_resend', { resend_to: resendTo, chef_division_type: chefDivType })
        }}
      />

      {/* Modal motif */}
      <MotifModal
        visible={motifModal.open}
        title={motifModal.action === 'secretaire_reject_final' ? 'Rejeter définitivement' : 'Rejeter la demande'}
        confirmLabel="Rejeter"
        confirmColor="danger"
        onClose={() => setMotifModal({ open: false, action: '' })}
        onConfirm={async (motif) => {
          await do_(motifModal.action, { motif })
          setMotifModal({ open: false, action: '' })
        }}
      />
    </>
  )
}

// ─── Vue principale ───────────────────────────────────────────────────────────
const SecretaireDashboard = () => {
  const getInitialTab = () => {
    const params = new URLSearchParams(window.location.search)
    const tab = params.get('tab')
    return tab && TABS.some(t => t.key === tab) ? tab : 'pending'
  }

  const [demandes, setDemandes]     = useState<DocumentRequest[]>([])
  const [loading, setLoading]       = useState(true)
  const [activeTab, setActiveTab]   = useState<string>(getInitialTab)
  const [search, setSearch]         = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [selected, setSelected]     = useState<DocumentRequest | null>(null)
  const [detailOpen, setDetailOpen] = useState(false)

  useEffect(() => {
    const syncTab = () => {
      const params = new URLSearchParams(window.location.search)
      const tab = params.get('tab')
      if (tab && TABS.some(t => t.key === tab)) setActiveTab(tab)
    }
    window.addEventListener('popstate', syncTab)
    return () => window.removeEventListener('popstate', syncTab)
  }, [])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await documentRequestService.getAll({ search, type: typeFilter })
      setDemandes(res.data || [])
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }, [search, typeFilter])

  useEffect(() => { load() }, [load])

  const filtered = demandes.filter(d => d.status === activeTab)

  const handleAction = async (action: string, extra?: Record<string, any>) => {
    if (!selected) return
    await documentRequestService.transition(selected.id, { action, ...extra })
    await load()
  }

  const counts = TABS.reduce((acc, tab) => {
    acc[tab.key] = demandes.filter(d => d.status === tab.key).length
    return acc
  }, {} as Record<string, number>)

  const switchTab = (key: string) => {
    setActiveTab(key)
    window.history.pushState(null, '', `?tab=${key}`)
  }

  return (
    <div>
      {/* En-tête stats */}
      <CRow className="mb-4 g-3">
        {[
          { key: 'pending',                 label: 'Nouvelles',     color: '#f59e0b', bg: '#fffbeb' },
          { key: 'rejected_pending_resend', label: 'Rejets',        color: '#ef4444', bg: '#fef2f2' },
          { key: 'ready',                   label: 'Prêts',         color: '#10b981', bg: '#ecfdf5' },
          { key: 'delivered',               label: 'Archivés',      color: '#6b7280', bg: '#f9fafb' },
        ].map(s => (
          <CCol key={s.key} md={3} sm={6}>
            <div
              className="rounded p-3 border cursor-pointer"
              style={{ background: s.bg, borderColor: s.color, cursor: 'pointer', borderLeftWidth: 4 }}
              onClick={() => switchTab(s.key)}
            >
              <div className="text-muted small">{s.label}</div>
              <div className="fw-bold" style={{ fontSize: '1.8rem', color: s.color }}>
                {counts[s.key] || 0}
              </div>
            </div>
          </CCol>
        ))}
      </CRow>

      <CCard className="shadow-sm">
        <CCardHeader className="bg-white">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <div>
              <strong className="fs-5">Gestion des demandes</strong>
              <div className="text-muted small">Secrétariat</div>
            </div>
            <div className="d-flex gap-2">
              <CInputGroup size="sm" style={{ width: 200 }}>
                <CInputGroupText><CIcon icon={cilSearch} /></CInputGroupText>
                <CFormInput
                  placeholder="Référence, nom…"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </CInputGroup>
              <CFormSelect
                size="sm"
                style={{ width: 170 }}
                value={typeFilter}
                onChange={e => setTypeFilter(e.target.value)}
              >
                <option value="">Tous les types</option>
                {Object.entries(TYPE_LABELS).map(([v, l]) => (
                  <option key={v} value={v}>{l}</option>
                ))}
              </CFormSelect>
            </div>
          </div>

          {/* Tabs */}
          <div className="d-flex gap-1 flex-wrap">
            {TABS.map(tab => {
              const isActive = activeTab === tab.key
              const count = counts[tab.key] || 0
              return (
                <button
                  key={tab.key}
                  onClick={() => switchTab(tab.key)}
                  style={{
                    border: isActive ? `2px solid var(--cui-${tab.color})` : '2px solid #e5e7eb',
                    background: isActive ? `var(--cui-${tab.color})` : 'white',
                    color: isActive ? 'white' : '#374151',
                    borderRadius: 6,
                    padding: '5px 12px',
                    fontSize: '0.78rem',
                    fontWeight: isActive ? 600 : 400,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    transition: 'all 0.15s',
                  }}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  {count > 0 && (
                    <span style={{
                      background: isActive ? 'rgba(255,255,255,0.3)' : '#e5e7eb',
                      color: isActive ? 'white' : '#374151',
                      borderRadius: 10,
                      padding: '0 6px',
                      fontSize: '0.7rem',
                      fontWeight: 700,
                    }}>
                      {count}
                    </span>
                  )}
                </button>
              )
            })}
          </div>
        </CCardHeader>

        <CCardBody className="p-0">
          {loading ? (
            <div className="text-center py-5">
              <CSpinner color="primary" />
              <div className="text-muted small mt-2">Chargement…</div>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-5 text-muted">
              <CIcon icon={cilInbox} size="3xl" className="mb-2 d-block mx-auto opacity-25" />
              <div>Aucune demande dans cette catégorie</div>
            </div>
          ) : (
            <CTable hover responsive className="align-middle mb-0">
              <CTableHead style={{ background: '#f8fafc' }}>
                <CTableRow>
                  <CTableHeaderCell>Référence</CTableHeaderCell>
                  <CTableHeaderCell>Étudiant</CTableHeaderCell>
                  <CTableHeaderCell>Type</CTableHeaderCell>
                  <CTableHeaderCell>Date</CTableHeaderCell>
                  <CTableHeaderCell>Statut</CTableHeaderCell>
                  <CTableHeaderCell>Action</CTableHeaderCell>
                  <CTableHeaderCell style={{ width: 60 }}></CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {filtered.map(d => (
                  <CTableRow
                    key={d.id}
                    style={{ cursor: 'pointer' }}
                    onClick={() => { setSelected(d); setDetailOpen(true) }}
                  >
                    <CTableDataCell>
                      <code style={{ fontSize: '0.82rem' }} className="text-primary">{d.reference}</code>
                    </CTableDataCell>
                    <CTableDataCell>
                      <div className="fw-semibold">{d.last_name} {d.first_names}</div>
                      <small className="text-muted">{d.matricule || '—'} · {d.department || '—'}</small>
                    </CTableDataCell>
                    <CTableDataCell>
                      <small>{TYPE_LABELS[d.type] ?? d.type}</small>
                    </CTableDataCell>
                    <CTableDataCell>
                      <small className="text-muted">
                        {d.submitted_at ? new Date(d.submitted_at).toLocaleDateString('fr-FR') : '—'}
                      </small>
                    </CTableDataCell>
                    <CTableDataCell>
                      <WorkflowBadge status={d.status} size="sm" />
                      {d.chef_division_type && (
                        <div className="mt-1">
                          <CBadge color="light" textColor="dark" style={{ fontSize: '0.65rem' }}>
                            {CHEF_DIVISION_LABELS[d.chef_division_type]}
                          </CBadge>
                        </div>
                      )}
                    </CTableDataCell>
                    <CTableDataCell>
                      <CButton color="primary" size="sm" variant="ghost">
                        <CIcon icon={cilExternalLink} />
                      </CButton>
                    </CTableDataCell>
                  </CTableRow>
                ))}
              </CTableBody>
            </CTable>
          )}
        </CCardBody>
      </CCard>

      <DetailModal
        demande={selected}
        visible={detailOpen}
        onClose={() => { setDetailOpen(false); setSelected(null) }}
        onAction={handleAction}
      />
    </div>
  )
}

export default SecretaireDashboard
